# Session 06 mock files

| File | Used on | Purpose |
|---|---|---|
| notes.txt | 1.1 / 1.2 | Read/write basics, matches the slide animation |
| expenses.csv | 1.3 demo | Has a header row so `csv.DictReader` works |
| expenses.json | 1.3 / M1 hands-on | Valid data for `load()` |
| expenses_corrupt.json | M1 hands-on test 3 | Triggers `json.JSONDecodeError` |
| weather_log.csv | M2 hands-on step 5 | Pre-filled log for highest/lowest (remember `float()`) |
| data/sample_open_meteo_response.json | 2.2 | Offline backup of the API response shape if the internet fails |

Test 2 (missing file): just rename or delete expenses.json.
